Spree.ready(function($) {

  $('[data-js-variants-trigger]').click(function() {
    var variants = $(this).closest('[data-js-variants]'),
        variant = variants.find('[data-js-variant-option]');

    variants.addClass('is-active');
    variant.change(updateVariantSelection);

    $(document).click(function(e) {
      var outOfBounds = !$(e.target).closest('[data-js-variants]').length;

      if (outOfBounds) { variants.removeClass('is-active'); }
    });
  });

  function updateVariantSelection(e) {
    var context = $(e.target).closest('[data-js-product]'),
        variants = context.find('[data-js-variant]'),
        variant = context.find('[data-js-variant=' + e.target.value + ']'),
        label = context.find('[data-js-variants-selected]')
          
    variants.addClass('is-hidden');
    variant.removeClass('is-hidden');

    context.find('[data-js-variants]').removeClass('is-active');
    context.find('[data-js-price]').text($(e.target).data('price'));
    label.text($(e.target).data('name'));
    $('[data-js-variant-stock]').text('');

    if ($(e.target).data('in-stock') === false) {
      $('[data-js-variant-stock]').text('Out of stock');
    }
  }
});
Spree.ready(function($) {
  // Adding AJAX to the wishlist items so they save and remain on the same page
  // instead of redirecting to the wishlist page

  $('form.new_wished_product').on('submit', function(e) {
    e.preventDefault();
    var dataString = $(this).serialize();
    var dataURL    = $(this).attr('action');
    var addBtn     = $(this).find('.WishlistForm_button');
    var removeBtn  = $(this).parent().find('.WishlistForm_remove');

    $.ajax({
        type: 'POST',
        url: dataURL,
        data: dataString,
        dataType: 'text',
        success: function(msg) {
          console.log('working: ',msg);
          addBtn.addClass('hidden');
          removeBtn.removeClass('hidden');

          // Temp hack so you can delete a wishlist product immediately after saving it
          // To fix will need to fork the wishlist gem and update in the controller
          location.reload();
        },
        error: function(msg) {
          console.log('not working ',msg);
        }
    });
  });

  $('.WishlistForm_remove').on('click', function(e) {
    e.preventDefault();
    var removeBtn  = $(this)
    var addBtn     = $(this).parent().find('.WishlistForm_button');

    removeBtn.addClass('hidden');
    addBtn.removeClass('hidden');

  });
});
Spree.ready(function($) {
  $('[data-js-accordion-trigger]').click(function() {
    var context = $(this).data('jsAccordionTrigger'),
        $target = $('[data-js-accordion-target=' + context + ']');

    $(this).toggleClass('is-active');
    $target.toggleClass('is-active');
  });

});
Spree.ready(function($) {
  $('[data-js-toggle-visibility-trigger]').click(function() {
    var target = $(this).data('jsToggleVisibilityTrigger');

    $('[data-js-toggle-visibility-target=' + target + ']').toggleClass('is-active');
  });
});
Spree.ready(function($) {

  $('[data-js-search-trigger]').click(function() {
    var search = $(this).parent('[data-js-search]');

    search.addClass('is-active');
    search.find('[data-js-search-input]').focus();

    $('[data-js-search-input]').blur(function() {
        search.removeClass('is-active');
    })
  });
});





