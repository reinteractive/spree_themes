# Overrides the base override to put the wishlist form in a different spot

Deface::Override.new(
  virtual_path: 'spree/products/show',
  name: 'add_wish_to_cart_form',
  insert_bottom: '[data-hook="wishlist_form"]',
  partial: 'spree/products/wishlist_form'
)
