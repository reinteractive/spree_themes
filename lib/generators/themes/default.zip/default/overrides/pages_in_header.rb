Deface::Override.new(
  virtual_path: 'spree/shared/_nav',
  name: 'pages_in_header',
  insert_bottom: '#main-nav-bar-static-pages',
  partial: 'spree/static_content/static_content_header'
)
