Spree.ready(function($) {

  $('[data-js-variants-trigger]').click(function() {
    var variants = $(this).closest('[data-js-variants]'),
        variant = variants.find('[data-js-variant-option]');

    variants.addClass('is-active');
    variant.change(updateVariantSelection);

    $(document).click(function(e) {
      var outOfBounds = !$(e.target).closest('[data-js-variants]').length;

      if (outOfBounds) { variants.removeClass('is-active'); }
    });
  });

  function updateVariantSelection(e) {
    var context = $(e.target).closest('[data-js-product]'),
        variants = context.find('[data-js-variant]'),
        variant = context.find('[data-js-variant=' + e.target.value + ']'),
        label = context.find('[data-js-variants-selected]')
          
    variants.addClass('is-hidden');
    variant.removeClass('is-hidden');

    context.find('[data-js-variants]').removeClass('is-active');
    context.find('[data-js-price]').text($(e.target).data('price'));
    label.text($(e.target).data('name'));
    $('[data-js-variant-stock]').text('');

    if ($(e.target).data('in-stock') === false) {
      $('[data-js-variant-stock]').text('Out of stock');
    }
  }
});
