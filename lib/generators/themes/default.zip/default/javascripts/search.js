Spree.ready(function($) {

  $('[data-js-search-trigger]').click(function() {
    var search = $(this).parent('[data-js-search]');

    search.addClass('is-active');
    search.find('[data-js-search-input]').focus();

    $('[data-js-search-input]').blur(function() {
        search.removeClass('is-active');
    })
  });
});
