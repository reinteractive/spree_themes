Spree.ready(function($) {
  // Adding AJAX to the wishlist items so they save and remain on the same page
  // instead of redirecting to the wishlist page

  $('form.new_wished_product').on('submit', function(e) {
    e.preventDefault();
    var dataString = $(this).serialize();
    var dataURL    = $(this).attr('action');
    var addBtn     = $(this).find('.WishlistForm_button');
    var removeBtn  = $(this).parent().find('.WishlistForm_remove');

    $.ajax({
        type: 'POST',
        url: dataURL,
        data: dataString,
        dataType: 'text',
        success: function(msg) {
          console.log('working: ',msg);
          addBtn.addClass('hidden');
          removeBtn.removeClass('hidden');

          // Temp hack so you can delete a wishlist product immediately after saving it
          // To fix will need to fork the wishlist gem and update in the controller
          location.reload();
        },
        error: function(msg) {
          console.log('not working ',msg);
        }
    });
  });

  $('.WishlistForm_remove').on('click', function(e) {
    e.preventDefault();
    var removeBtn  = $(this)
    var addBtn     = $(this).parent().find('.WishlistForm_button');

    removeBtn.addClass('hidden');
    addBtn.removeClass('hidden');

  });
});
