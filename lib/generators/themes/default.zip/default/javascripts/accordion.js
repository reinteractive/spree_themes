Spree.ready(function($) {
  $('[data-js-accordion-trigger]').click(function() {
    var context = $(this).data('jsAccordionTrigger'),
        $target = $('[data-js-accordion-target=' + context + ']');

    $(this).toggleClass('is-active');
    $target.toggleClass('is-active');
  });

});
