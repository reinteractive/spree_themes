Spree.ready(function($) {
  $('[data-js-toggle-visibility-trigger]').click(function() {
    var target = $(this).data('jsToggleVisibilityTrigger');

    $('[data-js-toggle-visibility-target=' + target + ']').toggleClass('is-active');
  });
});
